% Omer Faruk VERGISIZ 2445138
% Ayse KILIC 2444768
clear
clc
%% DATAS %% 
%{
grid(x,y,1:5) = 
1: statue of infection = 0 empty                   
                       = 1 non-infected
                       = 2 non-isolated infected
                       = 3 isolated infected
2: statue of move = 0 not moved yet
                  = 1 moved
3-4: infection counter = 0 not infected yet
                       = 1:30 infected
                       = 31 immune
5-6: isolation center X = 1:20
7-8: isolation center Y = 1:20
9  : vaccination counter = 0:2
10 : vaccination ban = 0 vaccination free
                     = 1 vaccination banned
11 : vaccination iteration counter = 0:3
%}

t       = 120;  % = 120;       % iterations
T       = 20;   % = 20;       % grid size (single edge)
N       = 240;  % = 240;      % population size
delta_1 = 0.05; % = 0.05;     % percentage of infected people initially 5%
p       = 0.5;  % = 0.5;      % infection probability in scenario of encounter 0.5
delta_2 = 0.50; % = 0.50;     % percentage of isolated infected people at the initialization 50%
qs      = 0.5;  % = 0.5;      % isolation probability of a newly infected person 0.5
M       = 30;   % = 30;       % infection duration (in number of iterations) 30
ts      = 20;   % = 20;       % iteration number where vaccination starts 20
rs      = 0.05; % = 0.05;     % infection probability of vaccinated healthy people 0.05
tsec    = 3;    % = 3;        % number of iterations between two vaccinations 3
w       = 0.8;  % = 0.8;      % second vaccination probability of healthy people 0.8
qh      = 0.95; % = 0.95;     % Each infected point will be healed with a 0.95 probability after M iterations
% tv = ts + time / 20 - 1; if mod(time, 20) == 0
% delta_3 = 1 / (2 * (tv - 19))     % rate of vaccination of healthy people

n_i = 0; % number of newly infected people in each iteration,
newlyInfectedList = [];
t_i = 0; % total number of infected people in the system in each iteration,
totalInfectedList = [];

n_h = 0; % number of newly healed people in each iteration,
newlyHealedList = [];
t_h = 0; % total number of healed people in the system in each iteration,
totalHealedList = [];

n_d = 0; % number of people that are died in each iteration.
newlyDeadList = [];
t_d = 0; % total number of dead people in the system in each iteration,
totalDeadList = [];

n_v = 0; % number of vaccinated people in each iteration,
newlyVaccinedList = [];
t_v = 0; % total number of vaccinated people in the system in each iteration,
totalVaccinedList = [];

n_v_i = 0; % number of infected people although they get vaccinated in each iteration,
newlyVaccinedInfectedList = [];

n_v_d = 0; % number of dead people who got vaccinated.
newlyVaccinedDeadList = [];
%% INITIALIZING PART %%
arr = zeros(1,T^2);
for i = 1:N*(1-delta_1)
    arr(i) = 1;
end
isole = 0;
non = 0;
for i = 1:N*delta_1
    a = rand;
    if rand < qs
        isole = isole + 1;
    else
        non = non + 1;
    end
end
for i = N*(1-delta_1)+1:isole+N*(1-delta_1)
    arr(i)= 3;
end
for i = isole+N*(1-delta_1)+1:N
    arr(i)= 2;
end
arr= arr(randperm(length(arr)));
grid = reshape(arr,[T,T]);
for i= 1:T
    for j= 1:T
        if grid(i,j)==1
            grid(i,j)= grid(i,j)*10^10;
        elseif grid(i,j)==3
            grid(i,j)= grid(i,j)*10^10;
            grid(i,j)= grid(i,j)+ i*100000 + j*1000;
        elseif grid(i,j)==2
            grid(i,j)= grid(i,j)*10^10;
        end
    end
end
grid = string(grid);
%% ITERATION PART %%
for time = 1:t
%% MOVE PART %%
    for i = 1:T
        for j = 1:T
            if grid(i,j) ~= "0"
                points = grid(i,j);                      % "12345678 23456789 34567891"
                points = split(points, " ", 2);          % ["12345678", "23456789", "34567891"]
                points = str2double(points);             % [12345678, 23456789, 34567891]
                s = numel(points);
                l = 1;
                for k = 1:s
                    point = points(l);                   % 12345678
                    point = divide_digits(point);        % [1 2 3 4 5 6 7 8]
                    
                    if point(2) == 0            % not moved yet
                        d = rand;               % direction
                        r = floor(rand*4);      % range
                        Tx = i; Ty = j;
                        
                        if point(1) == 1    % non-infected
                            % up
                            if    (.000 <= d && d < .125 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 0/5 < d && d < 1/5)		 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 0/5 < d && d <= 1/5)	 || (2 <= Tx && Tx <= T-1 && Ty == T && 0/5 < d && d <= 1/5)		 || (Tx == T && Ty == T && 0/3 < d && d <= 1/3)	 || (Tx == T && Ty == 1 && 0/3 < d && d <= 1/3)	
                                if Tx - r >= 1
                                    Tx = Tx - r;
                                else
                                    Tx = 1;
                                end                
    
                            % up right
                            elseif(.125 <= d && d < .250 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 1/5 < d && d < 2/5)		 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 1/5 < d && d <= 2/5)				 || (Tx == T && Ty == 1 && 1/3 < d && d <= 2/3)	
                                if Tx - r >= 1 && Ty + r <= T
                                    Tx = Tx - r; Ty = Ty + r;
                                else
                                    r = min((Tx - 1), (T - Ty));
                                    Tx = Tx - r; Ty = Ty + r;
                                end

                            % right
                            elseif(.250 <= d && d < .375 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 2/5 < d && d < 3/5)	 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 0/5 < d && d <= 1/5)	 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 2/5 < d && d <= 3/5)				 || (Tx == T && Ty == 1 && 2/3 < d && d <= 3/3)	 || (Tx == 1 && Ty == 1 && 0/3 < d && d <= 1/3)
                                if Ty + r <= T
                                    Ty = Ty + r;
                                else
                                    Ty = T;
                                end

                            
                            % down right
                            elseif(.375 <= d && d < .500 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)		 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 1/5 < d && d <= 2/5)	 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 3/5 < d && d <= 4/5) 					 || (Tx == 1 && Ty == 1 && 1/3 < d && d <= 2/3)
                                if Tx + r <= T && Ty + r <= T
                                    Tx = Tx + r; Ty = Ty + r;
                                else
                                    r = min((T - Tx), (T - Ty));
                                    Tx = Tx + r; Ty = Ty + r;
                                end

                            % down
                            elseif(.500 <= d && d < .625 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)		 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 2/5 < d && d <= 3/5)	 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 4/5 < d && d <= 5/5)	 || (2 <= Tx && Tx <= T-1 && Ty == T && 1/5 < d && d <= 2/5)	 || (Tx == 1 && Ty == T && 0/3 < d && d <= 1/3)			 || (Tx == 1 && Ty == 1 && 2/3 < d && d <= 3/3)
                                if Tx + r <= T
                                    Tx = Tx + r;
                                else
                                    Tx = T;
                                end
                            
                            % down left
                            elseif(.625 <= d && d < .750 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)		 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 3/5 < d && d <= 4/5)		 || (2 <= Tx && Tx <= T-1 && Ty == T && 2/5 < d && d <= 3/5)	 || (Tx == 1 && Ty == T && 1/3 < d && d <= 2/3)			
                                if Tx + r <= T && Ty - r >= 1
                                    Tx = Tx + r; Ty = Ty - r;
                                else
                                    r = min((T - Tx), (Ty - 1));
                                    Tx = Tx + r; Ty = Ty - r;
                                end
                                
                                
                            %left
                            elseif(.750 <= d && d < .875 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 3/5 < d && d < 4/5)	 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 4/5 < d && d <= 5/5)		 || (2 <= Tx && Tx <= T-1 && Ty == T && 3/5 < d && d <= 4/5)	 || (Tx == 1 && Ty == T && 2/3 < d && d <= 3/3)	 || (Tx == T && Ty == T && 1/3 < d && d <= 2/3)		
                                if Ty - r >= 1
                                    Ty = Ty - r;
                                else
                                    Ty = 1;
                                end
                            
                            % up left
                            elseif(.875 <= d && d < 1.00 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 4/5 < d && d < 5/5)			 || (2 <= Tx && Tx <= T-1 && Ty == T && 4/5 < d && d <= 5/5)		 || (Tx == T && Ty == T && 2/3 < d && d <= 3/3)		
                                if Tx - r >= 1 && Ty - r >= 1
                                    Tx = Tx - r; Ty = Ty - r;
                                else
                                    r = min((Tx - 1), (Ty - 1));
                                    Tx = Tx - r; Ty = Ty - r;
                                end
                            end
                            point(2) = 1;
                            point = combine_digits(point); 
                            point = num2str(point);
                        
                        elseif point(1) == 2    % non-isolated infected
                            % up
                            if    (.000 <= d && d < .125 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 0/5 < d && d < 1/5)		 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 0/5 < d && d <= 1/5)	 || (2 <= Tx && Tx <= T-1 && Ty == T && 0/5 < d && d <= 1/5)		 || (Tx == T && Ty == T && 0/3 < d && d <= 1/3)	 || (Tx == T && Ty == 1 && 0/3 < d && d <= 1/3)	
                                if Tx - r >= 1
                                    Tx = Tx - r;
                                else
                                    Tx = 1;
                                end  
                   
                            % up right
                            elseif(.125 <= d && d < .250 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 1/5 < d && d < 2/5)		 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 1/5 < d && d <= 2/5)				 || (Tx == T && Ty == 1 && 1/3 < d && d <= 2/3)	
                                if Tx - r >= 1 && Ty + r <= T
                                    Tx = Tx - r; Ty = Ty + r;
                                else
                                    r = min((Tx - 1), (T - Ty));
                                    Tx = Tx - r; Ty = Ty + r;
                                end
                                
                            % right
                            elseif(.250 <= d && d < .375 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 2/5 < d && d < 3/5)	 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 0/5 < d && d <= 1/5)	 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 2/5 < d && d <= 3/5)				 || (Tx == T && Ty == 1 && 2/3 < d && d <= 3/3)	 || (Tx == 1 && Ty == 1 && 0/3 < d && d <= 1/3)
                                if Ty + r <= T
                                    Ty = Ty + r;
                                else
                                    Ty = T;
                                end
                            
                            % down right
                            elseif(.375 <= d && d < .500 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)		 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 1/5 < d && d <= 2/5)	 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 3/5 < d && d <= 4/5) 					 || (Tx == 1 && Ty == 1 && 1/3 < d && d <= 2/3)
                                if Tx + r <= T && Ty + r <= T
                                    Tx = Tx + r; Ty = Ty + r;
                                else
                                    r = min((T - Tx), (T - Ty));
                                    Tx = Tx + r; Ty = Ty + r;
                                end

                            % down
                            elseif(.500 <= d && d < .625 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)		 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 2/5 < d && d <= 3/5)	 || (2 <= Tx && Tx <= T-1 && Ty == 1 && 4/5 < d && d <= 5/5)	 || (2 <= Tx && Tx <= T-1 && Ty == T && 1/5 < d && d <= 2/5)	 || (Tx == 1 && Ty == T && 0/3 < d && d <= 1/3)			 || (Tx == 1 && Ty == 1 && 2/3 < d && d <= 3/3)
                                if Tx + r <= T
                                    Tx = Tx + r;
                                else
                                    Tx = T;
                                end

                            % down left
                            elseif(.625 <= d && d < .750 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)		 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 3/5 < d && d <= 4/5)		 || (2 <= Tx && Tx <= T-1 && Ty == T && 2/5 < d && d <= 3/5)	 || (Tx == 1 && Ty == T && 1/3 < d && d <= 2/3)			
                                if Tx + r <= T && Ty - r >= 1
                                    Tx = Tx + r; Ty = Ty - r;
                                else
                                    r = min((T - Tx), (Ty - 1));
                                    Tx = Tx + r; Ty = Ty - r;
                                end

                            %left
                            elseif(.750 <= d && d < .875 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 3/5 < d && d < 4/5)	 || (2 <= Ty && Ty <= T-1 && Tx == 1 && 4/5 < d && d <= 5/5)		 || (2 <= Tx && Tx <= T-1 && Ty == T && 3/5 < d && d <= 4/5)	 || (Tx == 1 && Ty == T && 2/3 < d && d <= 3/3)	 || (Tx == T && Ty == T && 1/3 < d && d <= 2/3)		
                                if Ty - r >= 1
                                    Ty = Ty - r;
                                else
                                    Ty = 1;
                                end

                            % up left
                            elseif(.875 <= d && d < 1.00 && 2 <= Tx && Tx <= T-1 && 2 <= Ty && Ty <= T-1)	 || (2 <= Ty && Ty <= T-1 && Tx == T && 4/5 < d && d < 5/5)			 || (2 <= Tx && Tx <= T-1 && Ty == T && 4/5 < d && d <= 5/5)		 || (Tx == T && Ty == T && 2/3 < d && d <= 3/3)		
                                if Tx - r >= 1 && Ty - r >= 1
                                    Tx = Tx - r; Ty = Ty - r;
                                else
                                    r = min((Tx - 1), (Ty - 1));
                                    Tx = Tx - r; Ty = Ty - r;
                                end
                            end
                            infection_counter = point(3:4);                             % [a b] 
                            infection_counter = combine_digits(infection_counter);      % ab
                            infection_counter = infection_counter + 1;                  % ab+1
                            infection_counter = divide_2_digits(infection_counter);       % [a b+1]
                            point(3:4) = infection_counter;                             % [x y a b+1 z ...]

                            point(2) = 1;
                            point = combine_digits(point); 
                            point = num2str(point);
                        
                        
                        elseif point(1) == 3    % isolated infected
                            ilx = combine_digits(point(5:6));
                            ily = combine_digits(point(7:8));
                            % up
                            if    (2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 0/8 < d && d <= 1/8)	 || (ilx == T && 2 <= ily && ily <= T - 1 && 0/5 < d && d <= 1/5)		 || (ily == 1 && 2 <= ilx && ilx <= T - 1 && 0/5 < d && d <= 1/5)	 || (ily == T && 2 <= ilx && ilx <= T - 1 && 0/5 < d && d <= 1/5)		 || (ilx == T && ily == T && 0/3 < d && d <= 1/3)	 || (ilx == T && ily == 1 && 0/3 < d && d <= 1/3)	
                                r = min(abs(Tx - 1), abs(ilx - 1 - Tx));
                                Tx = Tx - r;
              
                            % up right
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 1/8 < d && d <= 2/8)	 || (ilx == T && 2 <= ily && ily <= T - 1 && 1/5 < d && d <= 2/5)		 || (ily == 1 && 2 <= ilx && ilx <= T - 1 && 1/5 < d && d <= 2/5)				 || (ilx == T && ily == 1 && 1/3 < d && d <= 2/3)	
                                r = min([abs(T - Ty), abs(Tx - 1), abs(ilx - 1 - Tx), abs(ily + 1 - Ty)]);
                                Tx = Tx - r; Ty = Ty + r;

                            % right
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 2/8 < d && d <= 3/8)	 || (ilx == T && 2 <= ily && ily <= T - 1 && 2/5 < d && d <= 3/5)	 || (ilx == 1 && 2 <= ily && ily <= T - 1 && 0/5 < d && d <= 1/5)	 || (ily == 1 && 2 <= ilx && ilx <= T - 1 && 2/5 < d && d <= 3/5)				 || (ilx == T && ily == 1 && 2/3 < d && d <= 3/3)	 || (ilx == 1 && ily == 1 && 0/3 < d && d <= 1/3)
                                r = min(abs(T - Ty), abs(ily + 1 - Ty));
                                Ty = Ty + r;

                            % down right
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 3/8 < d && d <= 4/8)		 || (ilx == 1 && 2 <= ily && ily <= T - 1 && 1/5 < d && d <= 2/5)	 || (ily == 1 && 2 <= ilx && ilx <= T - 1 && 3/5 < d && d <= 4/5)					 || (ilx == 1 && ily == 1 && 1/3 < d && d <= 2/3)
                                r = min([abs(T - Tx), abs(T - Ty), abs(ilx + 1 - Tx), abs(ily + 1 - Ty)]);
                                Tx = Tx + r; Ty = Ty + r;

                            % down
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 4/8 < d && d <= 5/8)		 || (ilx == 1 && 2 <= ily && ily <= T - 1 && 2/5 < d && d <= 3/5)	 || (ily == 1 && 2 <= ilx && ilx <= T - 1 && 4/5 < d && d <= 5/5)	 || (ily == T && 2 <= ilx && ilx <= T - 1 && 1/5 < d && d <= 2/5)	 || (ilx == 1 && ily == T && 0/3 < d && d <= 1/3)			 || (ilx == 1 && ily == 1 && 2/3 < d && d <= 3/3)
                                r = min(abs(T - Tx), abs(ily + 1 - Tx));
                                Tx = Tx + r;

                            % down left
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 5/8 < d && d <= 6/8)		 || (ilx == 1 && 2 <= ily && ily <= T - 1 && 3/5 < d && d <= 4/5)		 || (ily == T && 2 <= ilx && ilx <= T - 1 && 2/5 < d && d <= 3/5)	 || (ilx == 1 && ily == T && 1/3 < d && d <= 2/3)			
                                r = min([abs(T - Tx), abs(Ty - 1), abs(ilx + 1 - Tx), abs(ily - 1 - Ty)]);
                                Tx = Tx + r; Ty = Ty - r;

                            %left
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 6/8 < d && d <= 7/8)	 || (ilx == T && 2 <= ily && ily <= T - 1 && 3/5 < d && d <= 4/5)	 || (ilx == 1 && 2 <= ily && ily <= T - 1 && 4/5 < d && d <= 5/5)		 || (ily == T && 2 <= ilx && ilx <= T - 1 && 3/5 < d && d <= 4/5)	 || (ilx == 1 && ily == T && 2/3 < d && d <= 3/3)	 || (ilx == T && ily == T && 1/3 < d && d <= 2/3)		
                                r = min(abs(Ty - 1), abs(ily - 1 - Ty));
                                Ty = Ty - r;

                            % up left
                            elseif(2 <= ilx && ilx <= T - 1 && 2 <= ily && ily <= T - 1 && 7/8 < d && d <= 8/8)	 || (ilx == T && 2 <= ily && ily <= T - 1 && 4/5 < d && d <= 5/5)			 || (ily == T && 2 <= ilx && ilx <= T - 1 && 4/5 < d && d <= 5/5)		 || (ilx == T && ily == T && 2/3 < d && d <= 3/3)		
                                r = min([abs(Tx - 1), abs(Ty - 1), abs(ilx - 1 - Tx), abs(ily - 1 - Ty)]);
                                Tx = Tx - r; Ty = Ty - r;
                            end
                            
                            infection_counter = point(3:4); 
                            infection_counter = combine_digits(infection_counter);
                            infection_counter = infection_counter + 1;
                            infection_counter = divide_2_digits(infection_counter);
                            point(3:4) = infection_counter;

                            point(2) = 1;
                            point = combine_digits(point); 
                            point = num2str(point);
                        end

                        if r ~= 0
                            if grid(Tx,Ty) ~= "0"
                                temp = grid(Tx,Ty);
                                temp = [temp point];
                                temp = join(temp);
                                grid(Tx,Ty) = temp;
                            else
                                grid(Tx,Ty) = point;
                            end
                        
                            points(l) = [];
                        else
                            point = str2double(point);
                            points(l) = point;
                        end
                        l = l - 1;
                    end
                    l = l + 1;
                end
                if numel(points) ~= 0
                    points = string(points);
                    points = join(points(1:end));
                elseif r ~= 0
                    points = "0";
                end
                grid(i,j) = points;
            end
        end
    end
%% CHECK PART %%
    current_healthy_number = 0;
    current_non_isolated_infected_number = 0;
    current_isolated_infected_number = 0;
    first_vaccinated_candidate = [];
    second_vaccinated_candidate = [];

    n_i = 0;
    n_d = 0;
    n_h = 0; 
    n_v = 0;
    n_v_d = 0;
    n_v_i = 0;
    for i = 1:T
        for j = 1:T
            if grid(i,j) ~= "0"         
%% wheter dead or alive %%
                points = grid(i,j);                                                 % "12345678 23456789 34567891"
                points = split(points, " ", 2);                                     % ["12345678", "23456789", "34567891"]
                points = str2double(points);                                        % [12345678, 23456789, 34567891]
                s = numel(points);

                l = 1;  
                for k = 1:s
                    point = points(l);                                              % 12345678
                    point = divide_digits(point);                                   % [1 2 3 4 5 6 7 8]
                    point(2) = 0;                                                   % to not moved again

                    infection_counter = point(3:4);                                 % [3 4]
                    infection_counter = combine_digits(infection_counter);          % 34

                    if infection_counter == M
                        live_or_die = rand;
                        if live_or_die < qh     % get healed
                            point(1) = 1;
                            point(5:6) = 0;
                            point(7:8) = 0;
                            infection_counter = infection_counter + 1;              % 35
                            infection_counter = divide_2_digits(infection_counter); % [3 5]
                            point(3:4) = infection_counter;                         % [1 2 3 5 5 6 7 8]
                            point = combine_digits(point);                          % 12355678
                            points(l) = point;                                      % [12355678, 23456789, 34567891]
                            n_h = n_h + 1;
                            t_h = t_h + 1;
                        else                    % die
                            n_d = n_d + 1;
                            t_d = t_d + 1;
                            if point(9) == 1
                                n_v_d = n_v_d + 1;
                            end
                            points(l) = [];                                         % []
                            l = l - 1;
                        end
                    else
                        point = combine_digits(point);                          % 12355678
                        points(l) = point;                                      % [12355678, 23456789, 34567891]
                    end
                    l = l + 1;
                end
%% transmit the disease %%
                disease_exist = false;
                s = numel(points);
                for k = 1:s
                    point = points(k);                                              % 12345678
                    point = divide_digits(point);                                   % [1 2 3 4 5 6 7 8]
                    if point(1) == 2 || point(1) == 3
                        disease_exist = true;
                    end
                end
                
                if disease_exist
                    for k = 1:s
                        point = points(k);                                              % 12345678
                        point = divide_digits(point);                                   % [1 2 3 4 5 6 7 8]
                        infection_counter = point(3:4);                                 % [3 4]
                        infection_counter = combine_digits(infection_counter);          % 34

                        transmission_probability = rand;
                        isolation_probability = rand;
                        vaccined_transmission_probability = rand;
                        
                        % non-vaccined non-isolated 
                        if     point(1) == 1 && point(9) == 0 && infection_counter ~= M+1 && transmission_probability <= p && isolation_probability > qs
                            n_i = n_i + 1;
                            t_i = t_i + 1;
                            point(1) = 2;
                            point(10) = 1;
                        
                        % vaccined non-isolated
                        elseif point(1) == 1 && point(9) == 1 && infection_counter ~= M+1 && transmission_probability <= rs  && isolation_probability > qs
                            n_v_i = n_v_i + 1;
                            n_i = n_i + 1;
                            t_i = t_i + 1;
                            point(1) = 2;
                            point(10) = 1;

                        % vaccined isolated 
                        elseif point(1) == 1 && point(9) == 1 && infection_counter ~= M+1 && transmission_probability <= rs && isolation_probability <= qs
                            n_v_i = n_v_i + 1;
                            n_i = n_i + 1;
                            t_i = t_i + 1;

                            point(1) = 3;
                            point(10) = 1;
                            ilx = divide_2_digits(i);                  % [1 2]
                            ily = divide_2_digits(j);                  % [0 1]
                            point(5:6) = ilx;
                            point(7:8) = ily;

                        % non-vaccined isolated 
                        elseif point(1) == 1 && point(9) == 0 && infection_counter ~= M+1 && transmission_probability <= p && isolation_probability <= qs
                            n_i = n_i + 1;
                            t_i = t_i + 1;
                            point(1) = 3;
                            point(10) = 1;
                            ilx = divide_2_digits(i);                  % [1 2]
                            ily = divide_2_digits(j);                  % [0 1]
                            point(5:6) = ilx;
                            point(7:8) = ily;
                        end
                        point = combine_digits(point);
                        points(k) = point;
                    end
                end
%% COUNT PART %%
                for k = 1:s
                    point = points(k);                                              % 12345678
                    point = divide_digits(point);                                   % [1 2 3 4 5 6 7 8]
                    if point(1) == 1
                        current_healthy_number = current_healthy_number + 1;
                        if point(9) == 1
                            point(11) = point(11) + 1;
                            point = combine_digits(point);
                            points(k) = point;
                            point = divide_digits(point);
                        end

                        second_vaccination_probability = rand;

                        if  point(1) == 1 && point(9) == 0 && mod(time, ts) == 0 
                            first_vaccinated_candidate = [first_vaccinated_candidate; [i j k]];
                        elseif point(10) == 0 && point(9) == 1 && point(11) == 3 && second_vaccination_probability <= w
                            second_vaccinated_candidate = [second_vaccinated_candidate; [i j k]];
                        elseif point(9) == 1 && point(11) == 3 && second_vaccination_probability > w
                            point(9) = 0;
                            point(10) = 1;
                            point(11) = 0;
                            point = combine_digits(point);
                            points(k) = point;
                            point = divide_digits(point);
                        end
                    elseif point(1) == 2
                        current_non_isolated_infected_number = current_non_isolated_infected_number + 1;
                    elseif point(1) == 3
                        current_isolated_infected_number = current_isolated_infected_number + 1;
                    end
                end
                if numel(points) ~= 0
                    points = string(points);
                    points = join(points(1:end));
                else
                    points = "0";
                end
                grid(i,j) = points;
            end%%
        end
    end
%% VACCINATION PART
    if mod(time, ts) == 0
        tv = ts + time / ts - 1;
        delta_3 = 1 / (2 * (tv - 19));
        vaccinationList = randperm(size(first_vaccinated_candidate, 1));
        vaccinationList = vaccinationList(1:floor(size(first_vaccinated_candidate, 1) * delta_3));
        for i = 1:size(first_vaccinated_candidate, 1) * delta_3
            Tx = first_vaccinated_candidate(vaccinationList(i), 1);
            Ty = first_vaccinated_candidate(vaccinationList(i), 2);
            Tk = first_vaccinated_candidate(vaccinationList(i), 3);

            points = grid(Tx, Ty);
            points = split(points, " ", 2);
            points = str2double(points);
            point  = points(Tk);
            point = divide_digits(point);

            point(9) = 1;
            
            point = combine_digits(point);
            points(Tk) = point;
            points = string(points);
            points = join(points(1:end));
            grid(Tx,Ty) = points;
            n_v = n_v + 1;
            t_v = t_v + 1;
        end
    end
    if size(second_vaccinated_candidate, 1) ~= 0
        for i = 1:size(second_vaccinated_candidate, 1)
            Tx = second_vaccinated_candidate(i, 1);
            Ty = second_vaccinated_candidate(i, 2);
            Tk = second_vaccinated_candidate(i, 3);

            points = grid(Tx, Ty);
            points = split(points, " ", 2);
            points = str2double(points);
            point  = points(Tk);
            point = divide_digits(point);

            point(9)  = 2;
            point(10) = 1;
            
            point = combine_digits(point);
            points(Tk) = point;
            points = string(points);
            points = join(points(1:end));
            grid(Tx,Ty) = points;
        end
    end
    
    newlyInfectedList = [newlyInfectedList n_i];
    totalInfectedList = [totalInfectedList t_i];
    newlyHealedList   = [newlyHealedList n_h];
    totalHealedList   = [totalHealedList t_h];
    newlyDeadList     = [newlyDeadList n_d];
    totalDeadList     = [totalDeadList t_d];
    
    newlyVaccinedList = [newlyVaccinedList n_v];
    totalVaccinedList = [totalVaccinedList t_v];
    newlyVaccinedInfectedList = [newlyVaccinedInfectedList n_v_i];
    newlyVaccinedDeadList     = [newlyVaccinedDeadList n_v_d];
    
    %{
    fprintf("time: %d\n", time)
    fprintf("%d = number of newly infected people in each iteration,\n",n_i)
    fprintf("%d = total number of infected people in the system in total iteration,\n",t_i)
    fprintf("%d = number of newly healed people in each iteration,\n",n_h)
    fprintf("%d = total number of healed people in the system in total iteration,\n",t_h)
    fprintf("%d = number of people that are died in that iteration.\n",n_d)
    fprintf("%d = total number of dead people in the system in total iteration,\n",t_d)
    fprintf("%d = number of vaccinated people in each iteration,\n",n_v)
    fprintf("%d = total number of vaccinated people in the system in each iteration,\n",t_v)
    fprintf("%d = number of infected people although they get vaccinated in each iteration,\n",n_v_i)
    fprintf("%d = number of dead people who got vaccinated.\n",n_v_d)

    fprintf("%d = current_healthy_number,\n",current_healthy_number)
    fprintf("%d = current_non_isolated_infected_number,\n",current_non_isolated_infected_number)
    fprintf("%d = current_isolated_infected_number,\n",current_isolated_infected_number)
    fprintf("%d = current number of people\n",current_healthy_number+current_non_isolated_infected_number+current_isolated_infected_number)
    fprintf("\n")
    %}
end
%% PLOTS %%
x_axis = linspace(1,120,120);
color_blue = [52, 152, 219]; color_blue = color_blue / 255;
%% Representation of Number of Newly Infected People
f1 = figure;
tiledlayout(2,2);
nexttile
plot(x_axis, newlyInfectedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Number of Newly Infected People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Number of Newly Infected People')
xlim([1 120])
ylim([0 25])

%% Representation of Total Number of Infected People
nexttile
plot(x_axis, totalInfectedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Total Number of Infected People')
xlabel('Number of Iteration')
ylabel('Total Number of Infected People')
xlim([1 120])
ylim([0 240])

%% Representation of Number of Newly Healed People
nexttile
plot(x_axis, newlyHealedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Number of Newly Healed People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Number of Newly Healed People')
xlim([1 120])
ylim([0 25])

%% Representation of Total Number of Healed People
nexttile
plot(x_axis, totalHealedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Total Number of Healed People')
xlabel('Number of Iteration')
ylabel('Total Number of Healed People')
xlim([1 120])
ylim([0 240])

%% Representation of Number of People That Are Died
f2 = figure;
tiledlayout(2,2);
nexttile
plot(x_axis, newlyDeadList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Number of People That Are Died in Each Iteration')
xlabel('Number of Iteration')
ylabel('Number of People That Are Died')
xlim([1 120])
ylim([0 3])

%% Representation of Total Number of Dead People
nexttile
plot(x_axis, totalDeadList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Total Number of Dead People')
xlabel('Number of Iteration')
ylabel('Total Number of Dead People')
xlim([1 120])
ylim([0 15])

%% Representation of Number of Vaccinated People in Each Iteration
nexttile
plot(x_axis, newlyVaccinedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Number of Newly Vaccinated People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Number of Newly Vaccinated People')
xlim([1 120])
ylim([0 50])

%% Representation of Total Number of Vaccinated People
nexttile
plot(x_axis, totalVaccinedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Total Number of Vaccinated People')
xlabel('Number of Iteration')
ylabel('Total Number of Vaccinated People')
xlim([1 120])
ylim([0 240])

%% Representation of Number of Vaccinated Infected People
f3 = figure;
tiledlayout(2,2);
nexttile
plot(x_axis, newlyVaccinedInfectedList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Number of Newly Vaccinated Infected People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Number of Newly Vaccinated Infected People')
xlim([1 120])
ylim([0 10])

%% Representation of Number of Vaccinated Dead People
nexttile
plot(x_axis, newlyVaccinedDeadList, 'color',  color_blue, 'LineWidth',2)

title('Representation of Number of Newly Vaccinated Dead People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Number of Newly Vaccinated Dead People')
xlim([1 120])
ylim([0 3])  