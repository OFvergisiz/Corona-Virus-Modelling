function arr = divide_2_digits(number)
    if number < 10
        arr(1) = 0;
        arr(2) = number;
    else
        number = divide_digits(number);
        arr(1) = number(1);
        arr(2) = number(2);
    end
end