clear
clc

%% Scenario 1 %%
load Scenario_1_converge_DATAS.mat
averageTotalnewlyDeadList = [];
averageTotalnewlyHealedList = [];
averageTotalnewlyInfectedList = [];
averageTotaltotalDeadList = [];
averageTotaltotalHealedList = [];
averageTotaltotalInfectedList = [];
for i = 1:120
	tndl = 0;
	tnhl = 0;
    tnil = 0;
    ttdl = 0;
    tthl = 0;
    ttil = 0;
    for j = 1:1000
        tndl = tndl + TotalnewlyDeadList(j,i);
        tnhl = tnhl + TotalnewlyHealedList(j,i);
        tnil = tnil + TotalnewlyInfectedList(j,i);
        ttdl = ttdl + TotaltotalDeadList(j,i);
        tthl = tthl + TotaltotalHealedList(j,i);
        ttil = ttil + TotaltotalInfectedList(j,i);
    end
    averageTotalnewlyDeadList = [averageTotalnewlyDeadList tndl];
    averageTotalnewlyHealedList = [averageTotalnewlyHealedList tnhl];
    averageTotalnewlyInfectedList = [averageTotalnewlyInfectedList tnil];
    averageTotaltotalDeadList = [averageTotaltotalDeadList ttdl];
    averageTotaltotalHealedList = [averageTotaltotalHealedList tthl];
    averageTotaltotalInfectedList = [averageTotaltotalInfectedList ttil];
end

averageTotalnewlyDeadList = averageTotalnewlyDeadList / 1000;
averageTotalnewlyHealedList = averageTotalnewlyHealedList / 1000;
averageTotalnewlyInfectedList = averageTotalnewlyInfectedList / 1000;
averageTotaltotalDeadList = averageTotaltotalDeadList / 1000;
averageTotaltotalHealedList = averageTotaltotalHealedList / 1000;
averageTotaltotalInfectedList = averageTotaltotalInfectedList / 1000;

S1_averageTotalnewlyDeadList = averageTotalnewlyDeadList;
S1_averageTotalnewlyHealedList = averageTotalnewlyHealedList;
S1_averageTotalnewlyInfectedList = averageTotalnewlyInfectedList;
S1_averageTotaltotalDeadList = averageTotaltotalDeadList;
S1_averageTotaltotalHealedList = averageTotaltotalHealedList;
S1_averageTotaltotalInfectedList = averageTotaltotalInfectedList;

%% Scenario 2 %%
load Scenario_2_converge_DATAS.mat
averageTotalnewlyDeadList = [];
averageTotalnewlyHealedList = [];
averageTotalnewlyInfectedList = [];
averageTotalnewlyVaccinedDeadList = [];
averageTotalnewlyVaccinedInfectedList = [];
averageTotalnewlyVaccinedList = [];
averageTotaltotalDeadList = [];
averageTotaltotalHealedList = [];
averageTotaltotalInfectedList = [];
averageTotaltotalVaccinedList = [];
for i = 1:120
	tndl = 0;
	tnhl = 0;
	tnil = 0;
    tnvdl = 0;
    tnvil = 0;
    tnvl = 0;
    ttdl = 0;
    tthl = 0;
    ttil = 0;
    ttvl = 0;
    for j = 1:100
        tndl = tndl + TotalnewlyDeadList(j,i);
        tnhl = tnhl + TotalnewlyHealedList(j,i);
        tnil = tnil + TotalnewlyInfectedList(j,i);
        tnvdl = tnvdl + TotalnewlyVaccinedDeadList(j,i);
        tnvil = tnvil + TotalnewlyVaccinedInfectedList(j,i);
        tnvl = tnvl + TotalnewlyVaccinedList(j,i);
        ttdl = ttdl + TotaltotalDeadList(j,i);
        tthl = tthl + TotaltotalHealedList(j,i);
        ttil = ttil + TotaltotalInfectedList(j,i);
        ttvl = ttvl + TotaltotalVaccinedList(j,i);
    end
    averageTotalnewlyDeadList = [averageTotalnewlyDeadList tndl];
    averageTotalnewlyHealedList = [averageTotalnewlyHealedList tnhl];
    averageTotalnewlyInfectedList = [averageTotalnewlyInfectedList tnil];
    averageTotalnewlyVaccinedDeadList = [averageTotalnewlyVaccinedDeadList tnvdl];
    averageTotalnewlyVaccinedInfectedList = [averageTotalnewlyVaccinedInfectedList tnvil];
    averageTotalnewlyVaccinedList = [averageTotalnewlyVaccinedList tnvl];
    averageTotaltotalDeadList = [averageTotaltotalDeadList ttdl];
    averageTotaltotalHealedList = [averageTotaltotalHealedList tthl];
    averageTotaltotalInfectedList = [averageTotaltotalInfectedList ttil];
    averageTotaltotalVaccinedList = [averageTotaltotalVaccinedList ttvl];
end

averageTotalnewlyDeadList = averageTotalnewlyDeadList / 100;
averageTotalnewlyHealedList = averageTotalnewlyHealedList / 100;
averageTotalnewlyInfectedList = averageTotalnewlyInfectedList / 100;
averageTotalnewlyVaccinedDeadList = averageTotalnewlyVaccinedDeadList / 100;
averageTotalnewlyVaccinedInfectedList = averageTotalnewlyVaccinedInfectedList / 100;
averageTotalnewlyVaccinedList = averageTotalnewlyVaccinedList / 100;
averageTotaltotalDeadList = averageTotaltotalDeadList / 100;
averageTotaltotalHealedList = averageTotaltotalHealedList / 100;
averageTotaltotalInfectedList = averageTotaltotalInfectedList / 100;
averageTotaltotalVaccinedList = averageTotaltotalVaccinedList / 100;

S2_averageTotalnewlyDeadList = averageTotalnewlyDeadList;
S2_averageTotalnewlyHealedList = averageTotalnewlyHealedList;
S2_averageTotalnewlyInfectedList = averageTotalnewlyInfectedList;
S2_averageTotalnewlyVaccinedDeadList = averageTotalnewlyVaccinedDeadList;
S2_averageTotalnewlyVaccinedInfectedList = averageTotalnewlyVaccinedInfectedList;
S2_averageTotalnewlyVaccinedList = averageTotalnewlyVaccinedList;
S2_averageTotaltotalDeadList = averageTotaltotalDeadList;
S2_averageTotaltotalHealedList = averageTotaltotalHealedList;
S2_averageTotaltotalInfectedList = averageTotaltotalInfectedList;
S2_averageTotaltotalVaccinedList = averageTotaltotalVaccinedList;

%% Scenario 3 %%
load Scenario_3_converge_DATAS.mat
averageTotalnewlyDeadList = [];
averageTotalnewlyHealedList = [];
averageTotalnewlyInfectedList = [];
averageTotalnewlyVaccinedDeadList = [];
averageTotalnewlyVaccinedInfectedList = [];
averageTotalnewlyVaccinedList = [];
averageTotaltotalDeadList = [];
averageTotaltotalHealedList = [];
averageTotaltotalInfectedList = [];
averageTotaltotalVaccinedList = [];
for i = 1:120
	tndl = 0;
	tnhl = 0;
	tnil = 0;
    tnvdl = 0;
    tnvil = 0;
    tnvl = 0;
    ttdl = 0;
    tthl = 0;
    ttil = 0;
    ttvl = 0;
    for j = 1:100
        tndl = tndl + TotalnewlyDeadList(j,i);
        tnhl = tnhl + TotalnewlyHealedList(j,i);
        tnil = tnil + TotalnewlyInfectedList(j,i);
        tnvdl = tnvdl + TotalnewlyVaccinedDeadList(j,i);
        tnvil = tnvil + TotalnewlyVaccinedInfectedList(j,i);
        tnvl = tnvl + TotalnewlyVaccinedList(j,i);
        ttdl = ttdl + TotaltotalDeadList(j,i);
        tthl = tthl + TotaltotalHealedList(j,i);
        ttil = ttil + TotaltotalInfectedList(j,i);
        ttvl = ttvl + TotaltotalVaccinedList(j,i);
    end
    averageTotalnewlyDeadList = [averageTotalnewlyDeadList tndl];
    averageTotalnewlyHealedList = [averageTotalnewlyHealedList tnhl];
    averageTotalnewlyInfectedList = [averageTotalnewlyInfectedList tnil];
    averageTotalnewlyVaccinedDeadList = [averageTotalnewlyVaccinedDeadList tnvdl];
    averageTotalnewlyVaccinedInfectedList = [averageTotalnewlyVaccinedInfectedList tnvil];
    averageTotalnewlyVaccinedList = [averageTotalnewlyVaccinedList tnvl];
    averageTotaltotalDeadList = [averageTotaltotalDeadList ttdl];
    averageTotaltotalHealedList = [averageTotaltotalHealedList tthl];
    averageTotaltotalInfectedList = [averageTotaltotalInfectedList ttil];
    averageTotaltotalVaccinedList = [averageTotaltotalVaccinedList ttvl];
end

averageTotalnewlyDeadList = averageTotalnewlyDeadList / 100;
averageTotalnewlyHealedList = averageTotalnewlyHealedList / 100;
averageTotalnewlyInfectedList = averageTotalnewlyInfectedList / 100;
averageTotalnewlyVaccinedDeadList = averageTotalnewlyVaccinedDeadList / 100;
averageTotalnewlyVaccinedInfectedList = averageTotalnewlyVaccinedInfectedList / 100;
averageTotalnewlyVaccinedList = averageTotalnewlyVaccinedList / 100;
averageTotaltotalDeadList = averageTotaltotalDeadList / 100;
averageTotaltotalHealedList = averageTotaltotalHealedList / 100;
averageTotaltotalInfectedList = averageTotaltotalInfectedList / 100;
averageTotaltotalVaccinedList = averageTotaltotalVaccinedList / 100;

S3_averageTotalnewlyDeadList = averageTotalnewlyDeadList;
S3_averageTotalnewlyHealedList = averageTotalnewlyHealedList;
S3_averageTotalnewlyInfectedList = averageTotalnewlyInfectedList;
S3_averageTotalnewlyVaccinedDeadList = averageTotalnewlyVaccinedDeadList;
S3_averageTotalnewlyVaccinedInfectedList = averageTotalnewlyVaccinedInfectedList;
S3_averageTotalnewlyVaccinedList = averageTotalnewlyVaccinedList;
S3_averageTotaltotalDeadList = averageTotaltotalDeadList;
S3_averageTotaltotalHealedList = averageTotaltotalHealedList;
S3_averageTotaltotalInfectedList = averageTotaltotalInfectedList;
S3_averageTotaltotalVaccinedList = averageTotaltotalVaccinedList;

%% Scenario 4 %%
load Scenario_4_converge_DATAS.mat
averageTotalnewlyDeadList = [];
averageTotalnewlyHealedList = [];
averageTotalnewlyInfectedList = [];
averageTotalnewlyVaccinedDeadList = [];
averageTotalnewlyVaccinedInfectedList = [];
averageTotalnewlyVaccinedList = [];
averageTotaltotalDeadList = [];
averageTotaltotalHealedList = [];
averageTotaltotalInfectedList = [];
averageTotaltotalVaccinedList = [];
for i = 1:120
	tndl = 0;
	tnhl = 0;
	tnil = 0;
    tnvdl = 0;
    tnvil = 0;
    tnvl = 0;
    ttdl = 0;
    tthl = 0;
    ttil = 0;
    ttvl = 0;
    for j = 1:100
        tndl = tndl + TotalnewlyDeadList(j,i);
        tnhl = tnhl + TotalnewlyHealedList(j,i);
        tnil = tnil + TotalnewlyInfectedList(j,i);
        tnvdl = tnvdl + TotalnewlyVaccinedDeadList(j,i);
        tnvil = tnvil + TotalnewlyVaccinedInfectedList(j,i);
        tnvl = tnvl + TotalnewlyVaccinedList(j,i);
        ttdl = ttdl + TotaltotalDeadList(j,i);
        tthl = tthl + TotaltotalHealedList(j,i);
        ttil = ttil + TotaltotalInfectedList(j,i);
        ttvl = ttvl + TotaltotalVaccinedList(j,i);
    end
    averageTotalnewlyDeadList = [averageTotalnewlyDeadList tndl];
    averageTotalnewlyHealedList = [averageTotalnewlyHealedList tnhl];
    averageTotalnewlyInfectedList = [averageTotalnewlyInfectedList tnil];
    averageTotalnewlyVaccinedDeadList = [averageTotalnewlyVaccinedDeadList tnvdl];
    averageTotalnewlyVaccinedInfectedList = [averageTotalnewlyVaccinedInfectedList tnvil];
    averageTotalnewlyVaccinedList = [averageTotalnewlyVaccinedList tnvl];
    averageTotaltotalDeadList = [averageTotaltotalDeadList ttdl];
    averageTotaltotalHealedList = [averageTotaltotalHealedList tthl];
    averageTotaltotalInfectedList = [averageTotaltotalInfectedList ttil];
    averageTotaltotalVaccinedList = [averageTotaltotalVaccinedList ttvl];
end

averageTotalnewlyDeadList = averageTotalnewlyDeadList / 100;
averageTotalnewlyHealedList = averageTotalnewlyHealedList / 100;
averageTotalnewlyInfectedList = averageTotalnewlyInfectedList / 100;
averageTotalnewlyVaccinedDeadList = averageTotalnewlyVaccinedDeadList / 100;
averageTotalnewlyVaccinedInfectedList = averageTotalnewlyVaccinedInfectedList / 100;
averageTotalnewlyVaccinedList = averageTotalnewlyVaccinedList / 100;
averageTotaltotalDeadList = averageTotaltotalDeadList / 100;
averageTotaltotalHealedList = averageTotaltotalHealedList / 100;
averageTotaltotalInfectedList = averageTotaltotalInfectedList / 100;
averageTotaltotalVaccinedList = averageTotaltotalVaccinedList / 100;

S4_averageTotalnewlyDeadList = averageTotalnewlyDeadList;
S4_averageTotalnewlyHealedList = averageTotalnewlyHealedList;
S4_averageTotalnewlyInfectedList = averageTotalnewlyInfectedList;
S4_averageTotalnewlyVaccinedDeadList = averageTotalnewlyVaccinedDeadList;
S4_averageTotalnewlyVaccinedInfectedList = averageTotalnewlyVaccinedInfectedList;
S4_averageTotalnewlyVaccinedList = averageTotalnewlyVaccinedList;
S4_averageTotaltotalDeadList = averageTotaltotalDeadList;
S4_averageTotaltotalHealedList = averageTotaltotalHealedList;
S4_averageTotaltotalInfectedList = averageTotaltotalInfectedList;
S4_averageTotaltotalVaccinedList = averageTotaltotalVaccinedList;

%% PLOTS %%
x_axis = linspace(1,120,120);
color_blue = [52, 152, 219]; color_blue = color_blue / 255;
color_red = [146, 43, 33]; color_red = color_red / 255;
color_yellow = [241, 196, 15]; color_yellow = color_yellow / 255;
color_purple = [142, 68, 173]; color_purple = color_purple / 255;
%% figure 1 %% Representation of Average Number of People That Are Died
f1 = figure;
plot(x_axis, S1_averageTotalnewlyDeadList, 'color',  color_blue, 'LineWidth',2)
hold on
plot(x_axis, S2_averageTotalnewlyDeadList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotalnewlyDeadList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotalnewlyDeadList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Number of People That Are Died in Each Iteration')
xlabel('Number of Iteration')
ylabel('Average Number of People That Are Died')
legend("Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 0.7])

%% figure 2 %% Representation of Average Number of Newly Healed People
f2 = figure;
plot(x_axis, S1_averageTotalnewlyHealedList, 'color',  color_blue, 'LineWidth',2)
hold on
plot(x_axis, S2_averageTotalnewlyHealedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotalnewlyHealedList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotalnewlyHealedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Number of Newly Healed People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Average Number of Newly Healed People')
legend("Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 15])

%% figure 3 %% Representation of Average Number of Newly Infected People
f3 = figure;
plot(x_axis, S1_averageTotalnewlyInfectedList, 'color',  color_blue, 'LineWidth',2)
hold on
plot(x_axis, S2_averageTotalnewlyInfectedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotalnewlyInfectedList, 'color',  color_yellow, 'LineWidth',2) 
hold on
plot(x_axis, S4_averageTotalnewlyInfectedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Number of Newly Infected People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Average Number of Newly Infected People')
legend("Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 15])

%% figure 4 %% Representation of Average Number of Newly Vaccinated Dead People
f4 = figure;
plot(x_axis, S2_averageTotalnewlyVaccinedDeadList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotalnewlyVaccinedDeadList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotalnewlyVaccinedDeadList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Number of Newly Vaccinated Dead People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Average Total Number of Newly Vaccinated Dead People')
legend("Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 0.05])

%% figure 5 %% Representation of Average Number of Newly Vaccinated Infected People
f5 = figure;
plot(x_axis, S2_averageTotalnewlyVaccinedInfectedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotalnewlyVaccinedInfectedList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotalnewlyVaccinedInfectedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Number of Newly Vaccinated Infected People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Average Number of Newly Vaccinated Infected People')
legend("Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 15])

%% figure 6 %% Representation of Average Number of Newly Vaccinated People
f6 = figure;
plot(x_axis, S2_averageTotalnewlyVaccinedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotalnewlyVaccinedList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotalnewlyVaccinedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Number of Newly Vaccinated People in Each Iteration')
xlabel('Number of Iteration')
ylabel('Average Number of Newly Vaccinated People')
legend("Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 35])

%% figure 7 %% Representation of Average Total Number of Dead People
f7 = figure;
plot(x_axis, S1_averageTotaltotalDeadList, 'color',  color_blue, 'LineWidth',2)
hold on
plot(x_axis, S2_averageTotaltotalDeadList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotaltotalDeadList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotaltotalDeadList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Total Number of People That Are Died')
xlabel('Number of Iteration')
ylabel('Average Total Number of People That Are Died')
legend("Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 15])

%% figure 8 %% Representation of Average Total Number of Healed People
f8 = figure;
plot(x_axis, S1_averageTotaltotalHealedList, 'color',  color_blue, 'LineWidth',2)
hold on
plot(x_axis, S2_averageTotaltotalHealedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotaltotalHealedList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotaltotalHealedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Total Number of Healed People')
xlabel('Number of Iteration')
ylabel('Average Total Number of Healed People')
legend("Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 240])

%% figure 9 %% Representation of Average Total Number of Infected People
f9 = figure;
plot(x_axis, S1_averageTotaltotalInfectedList, 'color',  color_blue, 'LineWidth',2)
hold on
plot(x_axis, S2_averageTotaltotalInfectedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotaltotalInfectedList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotaltotalInfectedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Total Number of Infected People')
xlabel('Number of Iteration')
ylabel('Average Total Number of Infected People')
legend("Scenario 1", "Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 240])

%% figure 10 %% Representation of Average Total Number of Vaccinated People
f10 = figure;
plot(x_axis, S2_averageTotaltotalVaccinedList, 'color',  color_red, 'LineWidth',2)
hold on
plot(x_axis, S3_averageTotaltotalVaccinedList, 'color',  color_yellow, 'LineWidth',2)
hold on
plot(x_axis, S4_averageTotaltotalVaccinedList, 'color',  color_purple, 'LineWidth',2)

title('Representation of Average Total Number of Vaccinated People')
xlabel('Number of Iteration')
ylabel('Average Total Number of Vaccinated People')
legend("Scenario 2", "Scenario 3", "Scenario 4")
xlim([1 120])
ylim([0 240])