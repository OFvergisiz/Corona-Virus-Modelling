function number = combine_digits(points)        % [1 2 3] -> 123
    s = numel(points);
    number = 0;
    for i = 1:s
        number = number * 10 + points(i);
    end
end