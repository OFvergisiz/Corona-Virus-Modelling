function arr = divide_digits(numbers)           % 123 -> [1 2 3]
    arr = [];
    while numbers ~= 0
        number = mod(numbers, 10);
        numbers = (numbers - number)/10;
        arr = [arr number];
    end
    arr = flip(arr);
end